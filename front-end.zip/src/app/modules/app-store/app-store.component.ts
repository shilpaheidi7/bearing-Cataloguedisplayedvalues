import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-store',
  templateUrl: './app-store.component.html',
  styleUrls: ['./app-store.component.scss'],
})
export class AppStoreComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
